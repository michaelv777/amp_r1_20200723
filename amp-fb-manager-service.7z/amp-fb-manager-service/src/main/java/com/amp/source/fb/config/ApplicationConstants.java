/**
 * 
 */
package com.amp.source.fb.config;

/**
 * @author mveksler
 *
 */
public class ApplicationConstants {
	public static final String PROPERTY_FILE_NAME = "amp-fbmanager-service.properties";
}
