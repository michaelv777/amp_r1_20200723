package com.amp.source.fb.interfaces;

public interface SourceWorkerBeanLocal {

}
