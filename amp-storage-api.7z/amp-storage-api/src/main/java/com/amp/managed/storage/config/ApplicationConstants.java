/**
 * 
 */
package com.amp.managed.storage.config;

/**
 * @author mveksler
 *
 */
public class ApplicationConstants {
	public static final String PROPERTY_FILE_NAME = "amp-storage-api.properties";
}
