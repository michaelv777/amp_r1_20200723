/**
 * 
 */
package com.amp.jpa.entities.manager;

/**
 * @author MVEKSLER
 *
 */
public interface IJPAEntity 
{
	public String getJPAEntityName();
}
