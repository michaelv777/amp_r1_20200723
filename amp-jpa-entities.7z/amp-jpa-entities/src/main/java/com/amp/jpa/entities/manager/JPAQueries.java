package com.amp.jpa.entities.manager;



public interface JPAQueries {
	public static final String CLIENT_FINDALL = "Client.findAll";
}
