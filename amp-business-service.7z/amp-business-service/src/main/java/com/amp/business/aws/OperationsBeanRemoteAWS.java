package com.amp.business.aws;

import com.amp.business.base.BusinessBeanBaseRemote;

public interface OperationsBeanRemoteAWS extends BusinessBeanBaseRemote
{

}
