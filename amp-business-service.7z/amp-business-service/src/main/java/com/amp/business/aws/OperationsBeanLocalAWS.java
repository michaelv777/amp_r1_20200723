package com.amp.business.aws;

import com.amp.business.base.BusinessBeanBaseLocal;

public interface OperationsBeanLocalAWS extends BusinessBeanBaseLocal
{

}
