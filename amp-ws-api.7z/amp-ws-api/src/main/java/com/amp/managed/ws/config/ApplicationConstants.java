/**
 * 
 */
package com.amp.managed.ws.config;

/**
 * @author mveksler
 *
 */
public class ApplicationConstants {
	public static final String PROPERTY_FILE_NAME = "amp-ws-api.properties";
}
