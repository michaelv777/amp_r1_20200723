package com.amp.source.youtube.interfaces;

public interface SourceWorkerBeanLocal {

}
