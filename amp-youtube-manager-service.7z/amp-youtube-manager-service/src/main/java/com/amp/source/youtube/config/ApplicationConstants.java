/**
 * 
 */
package com.amp.source.youtube.config;

/**
 * @author mveksler
 *
 */
public class ApplicationConstants {
	public static final String PROPERTY_FILE_NAME = "amp-ytmanager-service.properties";
}
