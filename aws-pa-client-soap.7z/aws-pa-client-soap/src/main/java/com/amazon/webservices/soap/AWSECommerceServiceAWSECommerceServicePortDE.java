/**
 * AWSECommerceServiceAWSECommerceServicePortDE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.3  Built on : May 30, 2016 (04:08:57 BST)
 */
package com.amazon.webservices.soap;


/*
 *  AWSECommerceServiceAWSECommerceServicePortDE java interface
 */
public interface AWSECommerceServiceAWSECommerceServicePortDE {
    /**
     * Auto generated method signature
     *
     * @param cartModify468
     */
    public com.amazon.webservices.soap.types.CartModifyResponse cartModify(
        com.amazon.webservices.soap.types.CartModify cartModify468)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param itemLookup470
     */
    public com.amazon.webservices.soap.types.ItemLookupResponse itemLookup(
        com.amazon.webservices.soap.types.ItemLookup itemLookup470)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param itemSearch472
     */
    public com.amazon.webservices.soap.types.ItemSearchResponse itemSearch(
        com.amazon.webservices.soap.types.ItemSearch itemSearch472)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartCreate474
     */
    public com.amazon.webservices.soap.types.CartCreateResponse cartCreate(
        com.amazon.webservices.soap.types.CartCreate cartCreate474)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param browseNodeLookup476
     */
    public com.amazon.webservices.soap.types.BrowseNodeLookupResponse browseNodeLookup(
        com.amazon.webservices.soap.types.BrowseNodeLookup browseNodeLookup476)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartGet478
     */
    public com.amazon.webservices.soap.types.CartGetResponse cartGet(
        com.amazon.webservices.soap.types.CartGet cartGet478)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartClear480
     */
    public com.amazon.webservices.soap.types.CartClearResponse cartClear(
        com.amazon.webservices.soap.types.CartClear cartClear480)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartAdd482
     */
    public com.amazon.webservices.soap.types.CartAddResponse cartAdd(
        com.amazon.webservices.soap.types.CartAdd cartAdd482)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param similarityLookup484
     */
    public com.amazon.webservices.soap.types.SimilarityLookupResponse similarityLookup(
        com.amazon.webservices.soap.types.SimilarityLookup similarityLookup484)
        throws java.rmi.RemoteException;

    //
}
