/**
 * AWSECommerceServiceAWSECommerceServicePortUK.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.3  Built on : May 30, 2016 (04:08:57 BST)
 */
package com.amazon.webservices.soap;


/*
 *  AWSECommerceServiceAWSECommerceServicePortUK java interface
 */
public interface AWSECommerceServiceAWSECommerceServicePortUK {
    /**
     * Auto generated method signature
     *
     * @param cartModify144
     */
    public com.amazon.webservices.soap.types.CartModifyResponse cartModify(
        com.amazon.webservices.soap.types.CartModify cartModify144)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param itemLookup146
     */
    public com.amazon.webservices.soap.types.ItemLookupResponse itemLookup(
        com.amazon.webservices.soap.types.ItemLookup itemLookup146)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param itemSearch148
     */
    public com.amazon.webservices.soap.types.ItemSearchResponse itemSearch(
        com.amazon.webservices.soap.types.ItemSearch itemSearch148)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartCreate150
     */
    public com.amazon.webservices.soap.types.CartCreateResponse cartCreate(
        com.amazon.webservices.soap.types.CartCreate cartCreate150)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param browseNodeLookup152
     */
    public com.amazon.webservices.soap.types.BrowseNodeLookupResponse browseNodeLookup(
        com.amazon.webservices.soap.types.BrowseNodeLookup browseNodeLookup152)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartGet154
     */
    public com.amazon.webservices.soap.types.CartGetResponse cartGet(
        com.amazon.webservices.soap.types.CartGet cartGet154)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartClear156
     */
    public com.amazon.webservices.soap.types.CartClearResponse cartClear(
        com.amazon.webservices.soap.types.CartClear cartClear156)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartAdd158
     */
    public com.amazon.webservices.soap.types.CartAddResponse cartAdd(
        com.amazon.webservices.soap.types.CartAdd cartAdd158)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param similarityLookup160
     */
    public com.amazon.webservices.soap.types.SimilarityLookupResponse similarityLookup(
        com.amazon.webservices.soap.types.SimilarityLookup similarityLookup160)
        throws java.rmi.RemoteException;

    //
}
