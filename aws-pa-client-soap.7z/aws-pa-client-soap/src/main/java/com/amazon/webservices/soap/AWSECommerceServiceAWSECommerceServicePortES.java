/**
 * AWSECommerceServiceAWSECommerceServicePortES.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.3  Built on : May 30, 2016 (04:08:57 BST)
 */
package com.amazon.webservices.soap;


/*
 *  AWSECommerceServiceAWSECommerceServicePortES java interface
 */
public interface AWSECommerceServiceAWSECommerceServicePortES {
    /**
     * Auto generated method signature
     *
     * @param cartModify522
     */
    public com.amazon.webservices.soap.types.CartModifyResponse cartModify(
        com.amazon.webservices.soap.types.CartModify cartModify522)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param itemLookup524
     */
    public com.amazon.webservices.soap.types.ItemLookupResponse itemLookup(
        com.amazon.webservices.soap.types.ItemLookup itemLookup524)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param itemSearch526
     */
    public com.amazon.webservices.soap.types.ItemSearchResponse itemSearch(
        com.amazon.webservices.soap.types.ItemSearch itemSearch526)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartCreate528
     */
    public com.amazon.webservices.soap.types.CartCreateResponse cartCreate(
        com.amazon.webservices.soap.types.CartCreate cartCreate528)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param browseNodeLookup530
     */
    public com.amazon.webservices.soap.types.BrowseNodeLookupResponse browseNodeLookup(
        com.amazon.webservices.soap.types.BrowseNodeLookup browseNodeLookup530)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartGet532
     */
    public com.amazon.webservices.soap.types.CartGetResponse cartGet(
        com.amazon.webservices.soap.types.CartGet cartGet532)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartClear534
     */
    public com.amazon.webservices.soap.types.CartClearResponse cartClear(
        com.amazon.webservices.soap.types.CartClear cartClear534)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartAdd536
     */
    public com.amazon.webservices.soap.types.CartAddResponse cartAdd(
        com.amazon.webservices.soap.types.CartAdd cartAdd536)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param similarityLookup538
     */
    public com.amazon.webservices.soap.types.SimilarityLookupResponse similarityLookup(
        com.amazon.webservices.soap.types.SimilarityLookup similarityLookup538)
        throws java.rmi.RemoteException;

    //
}
