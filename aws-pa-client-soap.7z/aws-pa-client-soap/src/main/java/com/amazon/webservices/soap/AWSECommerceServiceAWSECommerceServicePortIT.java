/**
 * AWSECommerceServiceAWSECommerceServicePortIT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.3  Built on : May 30, 2016 (04:08:57 BST)
 */
package com.amazon.webservices.soap;


/*
 *  AWSECommerceServiceAWSECommerceServicePortIT java interface
 */
public interface AWSECommerceServiceAWSECommerceServicePortIT {
    /**
     * Auto generated method signature
     *
     * @param cartModify360
     */
    public com.amazon.webservices.soap.types.CartModifyResponse cartModify(
        com.amazon.webservices.soap.types.CartModify cartModify360)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param itemLookup362
     */
    public com.amazon.webservices.soap.types.ItemLookupResponse itemLookup(
        com.amazon.webservices.soap.types.ItemLookup itemLookup362)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param itemSearch364
     */
    public com.amazon.webservices.soap.types.ItemSearchResponse itemSearch(
        com.amazon.webservices.soap.types.ItemSearch itemSearch364)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartCreate366
     */
    public com.amazon.webservices.soap.types.CartCreateResponse cartCreate(
        com.amazon.webservices.soap.types.CartCreate cartCreate366)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param browseNodeLookup368
     */
    public com.amazon.webservices.soap.types.BrowseNodeLookupResponse browseNodeLookup(
        com.amazon.webservices.soap.types.BrowseNodeLookup browseNodeLookup368)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartGet370
     */
    public com.amazon.webservices.soap.types.CartGetResponse cartGet(
        com.amazon.webservices.soap.types.CartGet cartGet370)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartClear372
     */
    public com.amazon.webservices.soap.types.CartClearResponse cartClear(
        com.amazon.webservices.soap.types.CartClear cartClear372)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param cartAdd374
     */
    public com.amazon.webservices.soap.types.CartAddResponse cartAdd(
        com.amazon.webservices.soap.types.CartAdd cartAdd374)
        throws java.rmi.RemoteException;

    /**
     * Auto generated method signature
     *
     * @param similarityLookup376
     */
    public com.amazon.webservices.soap.types.SimilarityLookupResponse similarityLookup(
        com.amazon.webservices.soap.types.SimilarityLookup similarityLookup376)
        throws java.rmi.RemoteException;

    //
}
