@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservices.amazon.com/AWSECommerceService/2013-08-01", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.amp.amazon.webservices.rest;
