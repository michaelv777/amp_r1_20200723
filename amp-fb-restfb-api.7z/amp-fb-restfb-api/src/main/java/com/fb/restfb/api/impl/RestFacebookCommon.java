package com.fb.restfb.api.impl;

public class RestFacebookCommon
{
	public final static String MY_APP_ID = "2108024322757186";
	
	public final static String MY_APP_SECRET = "499196970a019d74f9efec00790d7611";
	
	public final static String MY_ACCESS_TOKEN = "EAAd9PKjvkkIBAL0fD2ZAkUVhZAia3vXI3jUVVBQ3nW0QAIYMyXlanzL58hHKnyt9FR1ZBMBlkZCW1iGEez7irN6f52VUMAnpKHZCDSVmBmY6PG6QouFYFCYJlJNieFrs9FE1yMIk3lLCW0fNfZBXJFV8o9vzOkIdTWIhg9tjNt1gZDZD";

	public final static String MY_APPLICATION_ACCESS_TOKEN = "2108024322757186|ioVkrS-KWFamS8eTEjY0m_8YdRU";
}
